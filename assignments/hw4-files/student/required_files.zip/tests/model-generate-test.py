OK_FORMAT = True

test = {   'name': 'model-generate-test',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_wrapped_generate():\n'
                                               '...     # This test tries to invoke generation API as what we are doing at the validation step\n'
                                               '...     decode_as_str(\n'
                                               '...         vocab,\n'
                                               '...         wrapped_generate(\n'
                                               '...             model_to_wrap=asr_pl_module.model,\n'
                                               '...             input_values=test_example.spectrograms.to(asr_pl_module.device),\n'
                                               '...             attention_mask=test_example.attention_mask.to(asr_pl_module.device)\n'
                                               '...         )\n'
                                               '...     )\n'
                                               '>>> \n'
                                               '>>> pub_test_wrapped_generate()\n',
                                       'failure_message': 'Failed to test `wrapped_generate()` function.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
