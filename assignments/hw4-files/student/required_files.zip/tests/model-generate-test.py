OK_FORMAT = True

test = {'name': 'model-generate-test', 'points': 2, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
