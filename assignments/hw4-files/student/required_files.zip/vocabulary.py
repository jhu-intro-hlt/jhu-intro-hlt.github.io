import enum
import json
from typing import Optional, List

import torch


# Special tokens
class SpecialToken(enum.Enum):
    BOS = '<BOS>'
    EOS = '<EOS>'
    UNK = '<UNK>'
    PAD = '<PAD>'
    SPACE = '<SPACE>'


class Vocabulary(object):
    def __init__(self,
                 tokens: Optional[List[str]] = None):
        # Registers `SpecialToken`
        self.special_token_enum = SpecialToken
        self._special_tokens = set([s.value for s in SpecialToken])
        if tokens is not None:
            tokens = set(tokens) | set(self._special_tokens)
        else:
            tokens = set(self._special_tokens)
        self._idx2token = list(tokens)
        self._token2idx = {t: i for i, t in enumerate(self._idx2token)}

    def add_token(self, token: str) -> int:
        if token not in self._idx2token:
            self._token2idx[token] = len(self._idx2token)
            self._idx2token.append(token)
        return self.token2idx(token)

    def to_file(self, file_path: str):
        with open(file_path, 'w') as f:
            json.dump({
                'idx2token': self._idx2token,
                'special_tokens': list(self._special_tokens),
                'token2idx': self._token2idx
            }, f, indent=2)

    @classmethod
    def from_file(cls, file_path: str) -> 'Vocabulary':
        with open(file_path) as f:
            read_data = json.load(f)
        vocab = Vocabulary()
        vocab._special_tokens = set(read_data['special_tokens'])
        vocab._idx2token = read_data['idx2token']
        vocab._token2idx = read_data['token2idx']
        return vocab

    def is_special(self, token: str) -> bool:
        return token in self._special_tokens

    def token2idx(self, token: str) -> int:
        return self._token2idx.get(token, self._token2idx[str(self.unk().value)])

    def idx2token(self, index: int) -> str:
        return self._idx2token[index]

    def bos(self) -> SpecialToken:
        return self.special_token_enum.BOS

    def eos(self) -> SpecialToken:
        return self.special_token_enum.EOS

    def unk(self) -> SpecialToken:
        return self.special_token_enum.UNK

    def pad(self) -> SpecialToken:
        return self.special_token_enum.PAD

    def special_to_id(self, st: SpecialToken) -> int:
        return self.token2idx(token=str(st.value))

    def bos_id(self) -> int:
        return self.special_to_id(st=self.bos())

    def eos_id(self) -> int:
        return self.special_to_id(st=self.eos())

    def unk_id(self) -> int:
        return self.special_to_id(st=self.unk())

    def pad_id(self) -> int:
        return self.special_to_id(st=self.pad())

    def __len__(self):
        return len(self._idx2token)


def _convert_special_space_to_space(token: str) -> str:
    if token == str(SpecialToken.SPACE.value):
        return ' '
    return token


def _convert_space_to_special_space(token: str) -> str:
    if token == ' ':
        return str(SpecialToken.SPACE.value)
    return token


def decode_as_str(tgt_vocab: Vocabulary, output_tensor: torch.Tensor) -> List[str]:
    """Decodes generation outputs to a list of strings."""
    outputs: List[List[int]] = output_tensor.detach().tolist()
    ignore_token_ids = (tgt_vocab.pad_id(), tgt_vocab.bos_id(), tgt_vocab.eos_id())
    decoded_strs: List[str] = [
        ''.join([
            _convert_special_space_to_space(tgt_vocab.idx2token(index=tid))  # Converts token id to token
            for tid in b
            if tid not in ignore_token_ids  # Filters special tokens
        ])  # Creates a decoded str
        for b in outputs  # Iterates over the batch
    ]
    return decoded_strs


def encode_as_tensor(src_vocab: Vocabulary, sentence: str) -> torch.Tensor:
    """Encodes a sentence to a tensor via the source vocabulary."""
    return torch.tensor(
        [
            [src_vocab.bos_id()]
            + [
                src_vocab.token2idx(_convert_space_to_special_space(token))
                for token in sentence  # .strip().split() - character-level
            ]
            + [src_vocab.eos_id()]
        ],
        dtype=torch.long
    )
