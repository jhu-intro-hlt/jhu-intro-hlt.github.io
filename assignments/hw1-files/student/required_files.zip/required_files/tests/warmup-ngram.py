OK_FORMAT = True

test = {   'name': 'warmup-ngram',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_check_return_type():\n'
                                               '...     test_trigrams = generate_ngrams_sentences([corpus[0]], 3)\n'
                                               '...     test_batch_trigrams = generate_ngrams_sentences(corpus[:2], 3)\n'
                                               "...     assert isinstance(test_trigrams, Counter), f'type={type(test_trigrams)}, should be `Counter`.'\n"
                                               "...     assert isinstance(test_batch_trigrams, Counter), f'type={type(test_batch_trigrams)}, should be `Counter`.'\n"
                                               '...     \n'
                                               '>>> pub_test_check_return_type()\n',
                                       'failure_message': 'Please make sure that `generate_ngrams()` and `generate_ngrams_sentences()` returns a `Counter`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def hid_test_simple_unigram():\n'
                                               "...     unigrams = generate_ngrams_sentences(['Introduction to Human Language Technology is an interesting course to learn natural language processing "
                                               ".'.split()], 1)\n"
                                               "...     references = Counter({('Introduction',): 1,\n"
                                               "...          ('to',): 2,\n"
                                               "...          ('Human',): 1,\n"
                                               "...          ('Language',): 1,\n"
                                               "...          ('Technology',): 1,\n"
                                               "...          ('is',): 1,\n"
                                               "...          ('an',): 1,\n"
                                               "...          ('interesting',): 1,\n"
                                               "...          ('course',): 1,\n"
                                               "...          ('learn',): 1,\n"
                                               "...          ('natural',): 1,\n"
                                               "...          ('language',): 1,\n"
                                               "...          ('processing',): 1,\n"
                                               "...          ('.',): 1})\n"
                                               "...     assert set(unigrams.keys()) == set(references.keys()), f'Expect:\\n\\t\\t{set(references.keys())}\\nGot:\\n\\t\\t{set(unigrams.keys())}.'\n"
                                               '...     for k in references.keys():\n'
                                               '...         assert unigrams[k] == references[k]\n'
                                               '...     \n'
                                               '>>> hid_test_simple_unigram()\n',
                                       'failure_message': 'Failed in unigram and bigram test.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
