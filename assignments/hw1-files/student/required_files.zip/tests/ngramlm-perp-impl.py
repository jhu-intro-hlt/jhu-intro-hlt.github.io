OK_FORMAT = True

test = {   'name': 'ngramlm-perp-impl',
    'points': 8,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_perplexity():\n'
                                               '...     assert np.isclose(perplexity(trigramlm, corpus[5:7]), 7.8673, atol=1e-4)\n'
                                               '...     assert np.isclose(perplexity(trigramlm, corpus[10:20]), 6.5040, atol=1e-4)\n'
                                               '...     assert np.isclose(perplexity(trigramlm, corpus[33:49]), 5.6819, atol=1e-4)\n'
                                               "...     assert np.isclose(perplexity(trigramlm, ['hello , world !'.split()]), np.inf, atol=1e-4)\n"
                                               "...     assert np.isclose(perplexity(trigramlm, ['you like him very much'.split()]), 14.01486, atol=1e-4)\n"
                                               '...     \n'
                                               '>>> pub_test_perplexity()\n',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 8}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
