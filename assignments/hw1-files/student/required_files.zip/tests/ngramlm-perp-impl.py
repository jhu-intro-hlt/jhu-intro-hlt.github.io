OK_FORMAT = True

test = {   'name': 'ngramlm-perp-impl',
    'points': 8,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_perplexity1():\n'
                                               '...     assert np.isclose(perplexity(trigramlm, corpus[5:7]), 7.8673, atol=1e-4)\n'
                                               '...     assert np.isclose(perplexity(trigramlm, corpus[10:20]), 6.5040, atol=1e-4)\n'
                                               '...     assert np.isclose(perplexity(trigramlm, corpus[33:49]), 5.6819, atol=1e-4)\n'
                                               '...     \n'
                                               '>>> pub_test_perplexity1()\n',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 4},
                                   {   'code': '>>> def pub_test_perplexity2():\n'
                                               "...     assert np.isclose(perplexity(trigramlm, ['hello , world !'.split()]), np.inf, atol=1e-4)\n"
                                               "...     assert np.isclose(perplexity(trigramlm, ['crazy , Hopkins !'.split()]), np.inf, atol=1e-4)\n"
                                               '...     \n'
                                               '>>> pub_test_perplexity2()\n',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_perplexity3():\n'
                                               "...     assert np.isclose(perplexity(trigramlm, ['you like him very much'.split()]), 14.01486, atol=1e-4)\n"
                                               "...     assert np.isclose(perplexity(trigramlm, ['i have'.split()]), 12.18471, atol=1e-4)\n"
                                               '...     \n'
                                               '>>> pub_test_perplexity3()\n',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
