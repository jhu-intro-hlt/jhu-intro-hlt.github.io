OK_FORMAT = True

test = {'name': 'cfg-tocnf', 'points': 4, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
