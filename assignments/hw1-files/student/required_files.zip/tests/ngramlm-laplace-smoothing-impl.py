OK_FORMAT = True

test = {   'name': 'ngramlm-laplace-smoothing-impl',
    'points': 15,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_lap_unk():\n'
                                               "...     assert np.isclose(trigramlm_laplace.word_prob(('~', '~'), '<UNK>'), 2.018122e-5, atol=1e-4)\n"
                                               "...     assert np.isclose(trigramlm_laplace.word_prob(('i', 'am'), '<UNK>'), 2.018122e-5, atol=1e-4)\n"
                                               '...     \n'
                                               '...         \n'
                                               '>>> pub_test_lap_unk()\n',
                                       'failure_message': 'The smoothed model should be able to handle OOV.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 3},
                                   {   'code': '>>> def pub_test_lap_unk_ctx():\n'
                                               "...     assert np.isclose(trigramlm_laplace.word_prob(('<UNK>', '<UNK>'), '<UNK>'), 5.71069613385e-05, atol=1e-5)    \n"
                                               '...         \n'
                                               '>>> pub_test_lap_unk_ctx()\n',
                                       'failure_message': 'The smoothed model should be able to handle OOV context.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 3},
                                   {   'code': '>>> def pub_test_lap_unk_candidates():\n'
                                               "...     assert '<UNK>' in trigramlm_laplace.next_word_candidates(('~', '~'))   \n"
                                               '...         \n'
                                               '>>> pub_test_lap_unk_candidates()\n',
                                       'failure_message': 'Candidates should include <UNK>.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
