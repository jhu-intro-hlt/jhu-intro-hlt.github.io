OK_FORMAT = True

test = {   'name': 'ngramlm-quad-perp-on-training',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> def hid_test_qgram_perp_on_training():\n'
                                               '...     assert np.isclose(qgram_perp_on_training, 2.2828, atol=1e-4)\n'
                                               '>>> \n'
                                               '>>> hid_test_qgram_perp_on_training()\n',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
