OK_FORMAT = True

test = {   'name': 'ngramlm-impl',
    'points': 20,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_check_update():\n'
                                               '...     trigram_to_test = NgramLM(n=3)\n'
                                               '...     trigram_to_test.update(corpus[0])\n'
                                               '...     \n'
                                               '...     # contexts\n'
                                               '...     for ctx, words in random.choices(list(trigramlm.contexts.items()), k=10):\n'
                                               '...         ngram_words = set()\n'
                                               '...         for ng, count in trigramlm.ngrams.items():\n'
                                               '...             if ng[:-1] != ctx:\n'
                                               '...                 continue\n'
                                               '...             ngram_words.add(ng[-1])\n'
                                               '...         assert words == ngram_words\n'
                                               '...     \n'
                                               '...     # vocab\n'
                                               "...     ref_vocab = {'and', 'are', 'buonapartes', 'estates', 'family', 'genoa', 'just', 'lucca', 'now', 'of', 'prince', 'so', 'the', 'well', '~'}\n"
                                               "...     assert '~' in trigramlm.vocab\n"
                                               '...     assert len(trigram_to_test.vocab & ref_vocab) == 15\n'
                                               '...     \n'
                                               '...     # ngrams\n'
                                               "...     ref_counter = Counter({('~', '~', 'well'): 1,\n"
                                               "...          ('~', 'well', 'prince'): 1,\n"
                                               "...          ('well', 'prince', 'so'): 1,\n"
                                               "...          ('prince', 'so', 'genoa'): 1,\n"
                                               "...          ('so', 'genoa', 'and'): 1,\n"
                                               "...          ('genoa', 'and', 'lucca'): 1,\n"
                                               "...          ('and', 'lucca', 'are'): 1,\n"
                                               "...          ('lucca', 'are', 'now'): 1,\n"
                                               "...          ('are', 'now', 'just'): 1,\n"
                                               "...          ('now', 'just', 'family'): 1,\n"
                                               "...          ('just', 'family', 'estates'): 1,\n"
                                               "...          ('family', 'estates', 'of'): 1,\n"
                                               "...          ('estates', 'of', 'the'): 1,\n"
                                               "...          ('of', 'the', 'buonapartes'): 1,\n"
                                               "...          ('the', 'buonapartes', '~'): 1,\n"
                                               "...          ('buonapartes', '~', '~'): 1})\n"
                                               '...     assert set(trigram_to_test.ngrams.keys()) == set(ref_counter.keys())\n'
                                               '...     for k in ref_counter.keys():\n'
                                               '...         assert trigram_to_test.ngrams[k] == ref_counter[k]\n'
                                               '...         \n'
                                               '...     # ngram_contexts\n'
                                               "...     context_ref_counter = Counter({('~', '~'): 1,\n"
                                               "...          ('~', 'well'): 1,\n"
                                               "...          ('well', 'prince'): 1,\n"
                                               "...          ('prince', 'so'): 1,\n"
                                               "...          ('so', 'genoa'): 1,\n"
                                               "...          ('genoa', 'and'): 1,\n"
                                               "...          ('and', 'lucca'): 1,\n"
                                               "...          ('lucca', 'are'): 1,\n"
                                               "...          ('are', 'now'): 1,\n"
                                               "...          ('now', 'just'): 1,\n"
                                               "...          ('just', 'family'): 1,\n"
                                               "...          ('family', 'estates'): 1,\n"
                                               "...          ('estates', 'of'): 1,\n"
                                               "...          ('of', 'the'): 1,\n"
                                               "...          ('the', 'buonapartes'): 1,\n"
                                               "...          ('buonapartes', '~'): 1})\n"
                                               '...     assert set(trigram_to_test.ngram_contexts.keys()) == set(context_ref_counter.keys())\n'
                                               '...     for k in context_ref_counter.keys():\n'
                                               '...         assert trigram_to_test.ngram_contexts[k] == context_ref_counter[k]\n'
                                               '>>> \n',
                                       'failure_message': 'Failed testing `.update()` method.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 4},
                                   {   'code': '>>> def pub_test_next_word_candidates():\n'
                                               "...     inclusion_check = {'infantry', 'charming', 'tomorrow', 'flower', 'shouts', 'twice', 'mutiny', 'zhilinski', 'their', 'mishka'}\n"
                                               '...     for i in inclusion_check:\n'
                                               "...         assert i in trigramlm.next_word_candidates(('~', '~'))\n"
                                               '...     \n'
                                               "...     inclusion_check_2 = {'another', 'her', 'nesvitski', 'princess', 'something', 'the', 'zherkov', '~'}\n"
                                               '...     for i in inclusion_check_2:\n'
                                               "...         assert i in trigramlm.next_word_candidates(('them', 'said')) \n"
                                               '>>> \n',
                                       'failure_message': 'Failed testing `.next_word_candidates()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_word_prob():\n'
                                               "...     assert np.isclose(trigramlm.word_prob(('~', '~'), 'hi'), 6.24e-05, atol=1e-7)\n"
                                               "...     assert np.isclose(trigramlm.word_prob(('~', '~'), 'another'), 0.0014357, atol=1e-7)\n"
                                               "...     assert np.isclose(trigramlm.word_prob(('the', 'gentle'), 'princess') , 0.25, atol=1e-7)\n"
                                               "...     assert np.isclose(trigramlm.word_prob(('to', 'a'), 'battle'), 0.00873362, atol=1e-7)\n"
                                               "...     assert np.isclose(trigramlm.word_prob(('to', 'a'), 'trot'), 0.0131004, atol=1e-7)\n"
                                               '...     \n',
                                       'failure_message': 'Failed testing `.word_prob()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_random_word():\n'
                                               '...     random.seed(5)\n'
                                               "...     ref_seq = ['yes', 'so', 'with', 'when', 'rostov', 'the', 'to', 'on', 'when', 'after']\n"
                                               "...     gen_seq = [trigramlm.random_word(('~', '~')) for _ in range(10)]\n"
                                               '...     print(gen_seq)\n'
                                               '...     for a, b in zip(ref_seq, gen_seq):\n'
                                               "...         assert a == b, f'a={a}, b={b}'\n"
                                               '>>> \n',
                                       'failure_message': 'Failed testing `.random_word()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_random_text(): \n'
                                               '...     random.seed(5)\n'
                                               '...     ref_seq = [\n'
                                               "...         ['~', '~', 'yes', '~'], \n"
                                               "...         ['~', '~', 'with', 'regard', 'to'], \n"
                                               "...         ['~', '~', 'the', 'second', 'time', 'the'], \n"
                                               "...         ['~', '~', 'after', 'reading', 'the', 'letter', 'and'], \n"
                                               "...         ['~', '~', 'we', 'seized', 'the', 'crossbeam', 'tugged', 'and'], \n"
                                               "...         ['~', '~', 'and', 'he', 'was', 'and', 'people', 'turned', 'away'], \n"
                                               "...         ['~', '~', 'the', 'officers', 'gazed', 'with', 'eyes', 'that', 'were', 'proposed'], \n"
                                               "...         ['~', '~', 'don', 't', 'you', 'wait', 'a', 'bit', 'kuragin', '~', '~']]\n"
                                               '...     gen_seq = [trigramlm.random_text(i) for i in range(2, 10)]\n'
                                               '...     for a, b in zip(ref_seq, gen_seq):\n'
                                               "...         assert ' '.join(a) == ' '.join(b), f'a={a}, b={b}'\n"
                                               '>>> \n',
                                       'failure_message': 'Failed testing `.random_text()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
