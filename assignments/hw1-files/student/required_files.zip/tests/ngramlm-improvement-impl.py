OK_FORMAT = True

test = {   'name': 'ngramlm-improvement-impl',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_handle_oov_improv_lm():\n'
                                               "...     assert improved_trigramlm.word_prob(('~', '~'), 'f34qjf9qjf') > 0.\n"
                                               '...         \n'
                                               '>>> pub_test_handle_oov_improv_lm()\n',
                                       'failure_message': 'Please make sure you have handled OOV.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
