OK_FORMAT = True

test = {   'name': 'ngramlm-improvement-impl',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_handle_oov_improv_lm():\n'
                                               "...     assert 1 >= improved_trigramlm.word_prob(('~', '~'), 'f34qjf9qjf') > 0.\n"
                                               '...         \n'
                                               '>>> pub_test_handle_oov_improv_lm()\n',
                                       'failure_message': 'Please make sure you have handled OOV and word_prob() is within [0, 1].',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def pub_test_improv_lm_context_type():\n'
                                               "...     assert isinstance(improved_trigramlm.contexts, dict), f'Expect `dict` got {type(improved_trigramlm.contexts)}'\n"
                                               '...         \n'
                                               '>>> pub_test_improv_lm_context_type()\n',
                                       'failure_message': 'improved_trigramlm.contexts type check failed.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def pub_test_all_sum_to_1():\n'
                                               '...     def _random_context():\n'
                                               '...         corpus_id = random.choices([0, 1], k=1)[0]\n'
                                               '...         if corpus_id == 0:  # From training\n'
                                               '...             sent = random.choices(corpus)[0]\n'
                                               '...         elif corpus_id == 1:  # From dev\n'
                                               '...             sent = random.choices(dev_text)[0]\n'
                                               '...         else: \n'
                                               '...             raise ValueError()\n'
                                               '...         if len(sent) < improved_trigramlm.n:\n'
                                               '...             return _random_context()\n'
                                               '...         \n'
                                               '...         ctx_start = random.randint(0, len(sent) - improved_trigramlm.n)\n'
                                               '...         return tuple(sent[ctx_start:ctx_start + improved_trigramlm.n - 1])\n'
                                               '...     \n'
                                               '...     full_vocab = set(\n'
                                               '...         [t for s in corpus for t in s]\n'
                                               '...         + [t for s in dev_text for t in s]\n'
                                               "...         + ['feaqwfeqjio',' zji129', 'v,1..', 'feq9018']\n"
                                               '...     )    \n'
                                               '...     for i in range(500):\n'
                                               '...         ctx = _random_context()\n'
                                               '...         non_unk_prob = sum([improved_trigramlm.word_prob(ctx, w) for w in full_vocab if w in improved_trigramlm.vocab])\n'
                                               '...         unks = [w for w in full_vocab if w not in improved_trigramlm.vocab]\n'
                                               '...         unk_prob = sum([improved_trigramlm.word_prob(ctx, w) for w in unks]) / len(unks)\n'
                                               '...         total_prob = non_unk_prob + unk_prob\n'
                                               "...         assert np.isclose(total_prob, 1.0, atol=5e-2) and total_prob < 1.05, f'Context={ctx}, NonUNKProb={non_unk_prob}, UNKProb={unk_prob}, "
                                               "Prob={total_prob}'\n"
                                               '...         \n'
                                               '>>> pub_test_all_sum_to_1()\n',
                                       'failure_message': 'Each marginialized distribution should sum to 1 - any p > 1 would result in inf perplexity.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 3}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
