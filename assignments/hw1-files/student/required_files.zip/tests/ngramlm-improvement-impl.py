OK_FORMAT = True

test = {   'name': 'ngramlm-improvement-impl',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_handle_oov_improv_lm():\n'
                                               "...     assert improved_trigramlm.word_prob(('~', '~'), 'f34qjf9qjf') > 0.\n"
                                               '...         \n'
                                               '>>> pub_test_handle_oov_improv_lm()\n',
                                       'failure_message': 'Please make sure you have handled OOV.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def pub_test_improv_lm_context_type():\n'
                                               "...     assert isinstance(improved_trigramlm.contexts, dict), f'Expect `dict` got {type(improved_trigramlm.contexts)}'\n"
                                               '...         \n'
                                               '>>> pub_test_improv_lm_context_type()\n',
                                       'failure_message': 'improved_trigramlm.contexts type check failed.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def pub_test_all_sum_to_1():\n'
                                               '...     for ctx, words in random.choices(list(improved_trigramlm.contexts.items()), k=500):\n'
                                               '...         non_unk_prob = sum([improved_trigramlm.word_prob(ctx, w) for w in improved_trigramlm.vocab])\n'
                                               "...         unk_prob = improved_trigramlm.word_prob(ctx, '<UNK>')\n"
                                               '...         total_prob = non_unk_prob + unk_prob\n'
                                               "...         assert np.isclose(total_prob, 1.0, atol=1e-2), f'Context={ctx}, NonUNKProb={non_unk_prob}, UNKProb={unk_prob}, Prob={total_prob}'\n"
                                               '...         \n'
                                               '>>> pub_test_all_sum_to_1()\n',
                                       'failure_message': 'Each marginialized distribution should sum to 1.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 3}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
