OK_FORMAT = True

test = {   'name': 'cyk-impl',
    'points': 25,
    'suites': [   {   'cases': [   {'code': '>>> parser.print_tree(parser.parse("I shot an elephant on my pajamas".split()))\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> def pub_test_cyk_sanity_checkes_ret_type():\n'
                                               '...     parser = CYKParser(cnf_cfg_rules)\n'
                                               '...     parse_table = parser.parse("I shot an elephant in my pajamas".split())\n'
                                               '...     \n'
                                               "...     assert isinstance(parse_table, list), f'Expect List, but got {type(parse_table)}'\n"
                                               "...     assert isinstance(parse_table[0], list), f'Expect List, but got {type(parse_table)}'\n"
                                               "...     assert isinstance(parse_table[0][0], list), f'Expect List, but got {type(parse_table)}'\n"
                                               '...     \n'
                                               '>>> pub_test_cyk_sanity_checkes_ret_type()\n',
                                       'failure_message': 'CYK parser failed the return type check, please do not change the return type.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1},
                                   {   'code': '>>> def pub_test_cyk_eg1():\n'
                                               '...     parser = CYKParser(cnf_cfg_rules)\n'
                                               '...     \n'
                                               '...     # case 1\n'
                                               '...     parse_table = parser.parse("I shot an elephant in my pajamas".split())\n'
                                               '...     ref = """[S [NP \'I\'] [VP [V \'shot\'] [NP [NP [Det \'an\'] [N \'elephant\']] [PP [P \'in\'] [NP [Det \'my\'] [N \'pajamas\']]]]]]"""\n'
                                               '...     \n'
                                               '...     start_symbol = parser.grammar.start().symbol()\n'
                                               '...     final_nodes = [n for n in parse_table[-1][0] if n.symbol == start_symbol]\n'
                                               '...     \n'
                                               '...     tree = [node.generate_tree() for node in final_nodes][0]  # This one only has one tree\n'
                                               '...     tree_str = str(tree)\n'
                                               "...     assert tree_str == ref, f'Yours={tree_str}, Ref={ref}'\n"
                                               '...     \n'
                                               '>>> pub_test_cyk_eg1()\n',
                                       'failure_message': 'Example test case failed for CYK.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5},
                                   {   'code': '>>> def pub_test_cyk_eg2():\n'
                                               '...     parser = CYKParser(cnf_cfg_rules)\n'
                                               '...     \n'
                                               '...     # case 2\n'
                                               '...     parse_table2 = parser.parse("I shot an elephant on my pajamas".split())\n'
                                               '...     final_nodes2 = [n for n in parse_table2[-1][0] if n.symbol == start_symbol]\n'
                                               '...     \n'
                                               "...     assert len(final_nodes2) == 0, f'The text should not be able to be parsed.'\n"
                                               '...     \n'
                                               '>>> pub_test_cyk_eg2()\n',
                                       'failure_message': 'Example test case failed for CYK.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5},
                                   {   'code': '>>> def hid_test_placeholder():\n...     assert False\n...     \n>>> hid_test_placeholder()\n',
                                       'failure_message': 'Hidden test cases for CYK have not been released yet.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 14}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
