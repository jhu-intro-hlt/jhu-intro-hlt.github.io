OK_FORMAT = True

test = {'name': 'cfg-iscnf', 'points': 1, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
