OK_FORMAT = True

test = {'name': 'cyk-impl', 'points': 25, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
