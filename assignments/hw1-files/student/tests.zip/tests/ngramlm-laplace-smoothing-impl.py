OK_FORMAT = True

test = {'name': 'ngramlm-laplace-smoothing-impl', 'points': 15, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
