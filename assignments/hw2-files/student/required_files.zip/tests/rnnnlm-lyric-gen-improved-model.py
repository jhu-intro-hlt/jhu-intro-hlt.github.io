OK_FORMAT = True

test = {   'name': 'rnnnlm-lyric-gen-improved-model',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_placeholder():\n...     assert False\n>>> \n>>> pub_test_placeholder()\n',
                                       'failure_message': 'Placeholder for tests.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 10}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
