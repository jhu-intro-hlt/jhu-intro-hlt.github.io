OK_FORMAT = True

test = {'name': 'rnnnlm-lyric-gen-improved-model', 'points': 10, 'suites': [{'cases': [], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
