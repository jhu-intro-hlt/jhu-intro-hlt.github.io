OK_FORMAT = True

test = {   'name': 'rnnnlm-lyric-gen-vanilla-rnn-impl',
    'points': 8,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_check_dimension_embeddings():\n'
                                               '...     test_rnn = VanillaRNN()\n'
                                               "...     assert test_rnn.embeddings.weight.shape == (101, 512), f'Dimension of `embeddings` is {test_rnn.embeddings.weight.shape} != (101, 512).'\n"
                                               "...     assert test_rnn.embeddings.padding_idx == PADDING_LABEL, f'Got padding_idx={test_rnn.embeddings.padding_idx} != {PADDING_LABEL}'\n"
                                               "...     assert (test_rnn.embeddings(torch.tensor([PADDING_LABEL], dtype=torch.long)) == 0.).all().item(), 'Got non-zero padding embedding.'\n"
                                               '>>> \n'
                                               '>>> pub_test_check_dimension_embeddings()\n',
                                       'failure_message': 'Failed to check the dimension for `embeddings`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_check_dimension_rnn():\n'
                                               '...     test_rnn = VanillaRNN()\n'
                                               "...     assert (test_rnn.rnn.input_size, test_rnn.rnn.hidden_size) == (512, 512), f'Dimension of `embeddings` is {(test_rnn.rnn.input_size, "
                                               "test_rnn.rnn.hidden_size)} != (512, 512).'\n"
                                               '>>> \n'
                                               '>>> pub_test_check_dimension_rnn()\n',
                                       'failure_message': 'Failed to check the dimension for `rnn`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_check_dimension_ffnn():\n'
                                               '...     test_rnn = VanillaRNN()\n'
                                               "...     assert test_rnn.ffnn.weight.shape == (100, 512), f'Dimension of `embeddings` is {test_rnn.ffnn.weight.shape} != (100, 512).'\n"
                                               "...     assert test_rnn.ffnn.bias.shape == (100, ), f'Dimension of `embeddings` is {test_rnn.ffnn.bias.shape} != (100, ).'\n"
                                               '>>> \n'
                                               '>>> pub_test_check_dimension_ffnn()\n',
                                       'failure_message': 'Failed to check the dimension for `ffnn`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> def pub_test_check_layer_rnn():\n'
                                               '...     test_rnn = VanillaRNN()\n'
                                               "...     assert test_rnn.rnn.num_layers == 2, f'The number of layers is {test_rnn.rnn.num_layers} != 2.'\n"
                                               '>>> \n'
                                               '>>> pub_test_check_layer_rnn()\n',
                                       'failure_message': 'Failed to check `rnn` number of layers.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
