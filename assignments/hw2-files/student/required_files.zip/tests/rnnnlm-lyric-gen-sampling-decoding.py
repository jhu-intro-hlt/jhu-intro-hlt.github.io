OK_FORMAT = True

test = {   'name': 'rnnnlm-lyric-gen-sampling-decoding',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_low_temp_sampling():\n'
                                               '...     greedy_decoder = greedy_decoding\n'
                                               '...     sampling_decoder = sampling_decoding\n'
                                               "...     starting_prefix = 'I want '\n"
                                               '...     starting_prefix_idx = string_to_labels(starting_prefix, oov_label=OOV_LABEL)\n'
                                               '...     greedy_hypo = greedy_decoder.decode(\n'
                                               '...         starting_hyp=Hypothesis(\n'
                                               '...             token_ids=torch.tensor([starting_prefix_idx], dtype=torch.long,\n'
                                               '...                                    device=vanilla_rnn_model.device),\n'
                                               '...             logits=torch.ones([1, len(starting_prefix_idx)], dtype=torch.float, device=vanilla_rnn_model.device),\n'
                                               '...             lengths=torch.tensor([len(starting_prefix_idx)], dtype=torch.long, device=vanilla_rnn_model.device)\n'
                                               '...         ),\n'
                                               '...     )[0]\n'
                                               '...     sampling_hypo = sampling_decoder.decode(\n'
                                               '...         starting_hyp=Hypothesis(\n'
                                               '...             token_ids=torch.tensor([starting_prefix_idx], dtype=torch.long,\n'
                                               '...                                    device=vanilla_rnn_model.device),\n'
                                               '...             logits=torch.ones([1, len(starting_prefix_idx)], dtype=torch.float, device=vanilla_rnn_model.device),\n'
                                               '...             lengths=torch.tensor([len(starting_prefix_idx)], dtype=torch.long, device=vanilla_rnn_model.device)\n'
                                               '...         ),\n'
                                               '...         temperature=1e-6\n'
                                               '...     )[0]\n'
                                               "...     assert tuple(greedy_hypo.token_ids.tolist()) == tuple(sampling_hypo.token_ids.tolist()), f'{tuple(greedy_hypo.token_ids.tolist())} != "
                                               "{tuple(sampling_hypo.token_ids.tolist())}'\n"
                                               '>>> \n'
                                               '>>> pub_test_low_temp_sampling()\n',
                                       'failure_message': 'Failed to test a close approximation to greedy decoding.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
