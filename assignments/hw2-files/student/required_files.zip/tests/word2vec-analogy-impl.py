OK_FORMAT = True

test = {   'name': 'word2vec-analogy-impl',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> \n'
                                               '>>> def pub_test_return_type():\n'
                                               "...     first_case = analogy('man', 'king', 'woman', 10)\n"
                                               "...     assert len(first_case) == 10, f'Expected length=10 but got {len(first_case)}.'\n"
                                               '...     assert all([isinstance(x, tuple) and isinstance(x[0], str) and isinstance(x[1], float) for x in\n'
                                               "...                 first_case]), 'Return types are not correct.'\n"
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_return_type()\n',
                                       'failure_message': 'Failed to test the return type.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2},
                                   {   'code': '>>> \n'
                                               '>>> \n'
                                               '>>> def pub_test_basic_case():\n'
                                               "...     first_case = analogy('man', 'king', 'woman', 1)[0][0]\n"
                                               '...     assert first_case == \'queen\', f\'Expect "queen", got {first_case}\'\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_basic_case()\n',
                                       'failure_message': 'Failed to test basic case.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
