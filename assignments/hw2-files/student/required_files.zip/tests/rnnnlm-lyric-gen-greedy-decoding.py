OK_FORMAT = True

test = {   'name': 'rnnnlm-lyric-gen-greedy-decoding',
    'points': 15,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_placeholder():\n'
                                               '...     assert False, f\'Your output is:\\n{"".join([all_characters[x] for x in decoded_hypos[0].token_ids.tolist()[0]])}\'\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_placeholder()\n',
                                       'failure_message': 'Placeholder for tests.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 15}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
