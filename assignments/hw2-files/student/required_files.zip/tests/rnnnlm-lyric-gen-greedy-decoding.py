OK_FORMAT = True

test = {   'name': 'rnnnlm-lyric-gen-greedy-decoding',
    'points': 15,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_batch_multiple():\n'
                                               '...     decoder = greedy_decoding\n'
                                               "...     starting_words = ['I', 'W', 'G', 'H']\n"
                                               '...     mhypos = decoder.decode(\n'
                                               '...         starting_hyp=Hypothesis(\n'
                                               '...             token_ids=torch.tensor([string_to_labels(w, oov_label=OOV_LABEL) for w in starting_words], dtype=torch.long,\n'
                                               '...                                    device=vanilla_rnn_model.device),\n'
                                               '...             logits=torch.ones([len(starting_words), 1], dtype=torch.float, device=vanilla_rnn_model.device),\n'
                                               '...             lengths=torch.ones([len(starting_words)], dtype=torch.long, device=vanilla_rnn_model.device)\n'
                                               '...         ),\n'
                                               '...     )[0]\n'
                                               "...     assert mhypos.token_ids.shape[0] == len(starting_words), f'deocded batch_size={mhypos.token_ids.shape[0]} != "
                                               "batch_size={len(starting_words)}.'\n"
                                               "...     assert mhypos.lengths.shape[0] == len(starting_words), f'deocded batch_size={mhypos.lengths.shape[0]} != batch_size={len(starting_words)}.'\n"
                                               "...     assert mhypos.logits.shape[0] == len(starting_words), f'deocded batch_size={mhypos.logits.shape[0]} != batch_size={len(starting_words)}.'\n"
                                               '>>> \n'
                                               '>>> pub_test_batch_multiple()\n',
                                       'failure_message': 'Failed to test batch processing of multiple hypotheses.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5},
                                   {   'code': '>>> def pub_test_decode_in_the_middle():\n'
                                               '...     decoder = greedy_decoding\n'
                                               "...     starting_prefix = 'I want to say hello world'\n"
                                               '...     starting_prefix_idx = string_to_labels(starting_prefix, oov_label=OOV_LABEL)\n'
                                               '...     mhypos = decoder.decode(\n'
                                               '...         starting_hyp=Hypothesis(\n'
                                               '...             token_ids=torch.tensor([starting_prefix_idx], dtype=torch.long,\n'
                                               '...                                    device=vanilla_rnn_model.device),\n'
                                               '...             logits=torch.ones([1, len(starting_prefix_idx)], dtype=torch.float, device=vanilla_rnn_model.device),\n'
                                               '...             lengths=torch.tensor([len(starting_prefix_idx)], dtype=torch.long, device=vanilla_rnn_model.device)\n'
                                               '...         ),\n'
                                               '...     )[0]\n'
                                               "...     assert tuple(mhypos.token_ids[0, :len(starting_prefix_idx)].tolist()) == tuple(starting_prefix_idx), f'Prefix does not match - you might have "
                                               "changed them in your decoding. {tuple(mhypos.token_ids[:len(starting_prefix_idx)].tolist())} - {tuple(starting_prefix_idx),}'\n"
                                               '>>> \n'
                                               '>>> pub_test_decode_in_the_middle()\n',
                                       'failure_message': 'Failed to decode from longer starting prefix.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 2}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
