OK_FORMAT = True

test = {   'name': 'rnnnlm-lyric-gen-greedy-decoding',
    'points': 15,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_placeholder():\n...     assert False\n>>> \n>>> pub_test_placeholder()\n',
                                       'failure_message': 'Placeholder for tests.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 15}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
