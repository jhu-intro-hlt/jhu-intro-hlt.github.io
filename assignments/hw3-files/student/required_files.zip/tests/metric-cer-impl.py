OK_FORMAT = True

test = {   'name': 'metric-cer-impl',
    'points': 12,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_compute_edit_distance():\n'
                                               "...     assert False, 'This is currently a placeholder.'\n"
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_compute_edit_distance()\n',
                                       'failure_message': 'Failed to test the `compute_edit_distance()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 12}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
