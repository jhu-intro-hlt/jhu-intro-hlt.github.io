OK_FORMAT = True

test = {   'name': 'metric-cer-impl',
    'points': 12,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_update_cer():\n'
                                               '...     assert compute_edit_distance("this is the prediction".split(), "there is an other sample".split()) == 4, \'The distance should be 4.\'\n'
                                               '...     assert compute_edit_distance("this".split(), "".split()) == 1, \'The distance should be 1.\'\n'
                                               '...     assert compute_edit_distance("this".split(), "hi".split()) == 1, \'The distance should be 1.\'\n'
                                               '...     assert compute_edit_distance("this".split(), "hi this".split()) == 1, \'The distance should be 1.\'\n'
                                               '...     assert compute_edit_distance("hello world".split(), "hello intro world hlt".split()) == 2, \'The distance should be 2.\'\n'
                                               '...     assert compute_edit_distance("".split(), "".split()) == 0, \'The distance should be 0.\'\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_update_cer()\n',
                                       'failure_message': 'Failed to test the `update_cer()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 6},
                                   {   'code': '>>> def pub_test_compute_edit_distance():\n'
                                               '...     first_test_result = update_cer("this is the prediction", "there is an other sample")\n'
                                               "...     assert isinstance(first_test_result[0], torch.Tensor) and isinstance(first_test_result[1], torch.Tensor), f'The outputs should be "
                                               "`torch.Tensor` type instead of ({type(first_test_result[0])}, {type(first_test_result[1])}).'\n"
                                               "...     assert first_test_result == (torch.tensor(17.), torch.tensor(24.)), 'The results do not match with references.'\n"
                                               '...     second_test_result = update_cer(\n'
                                               '...         ["this is the prediction", "this", ""],\n'
                                               '...         ["there is an other sample", "hi", ""]\n'
                                               '...     )\n'
                                               "...     assert second_test_result == (torch.tensor(19.), torch.tensor(26.)), 'The results do not match with references.'\n"
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_compute_edit_distance()\n',
                                       'failure_message': 'Failed to test the `compute_edit_distance()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 3},
                                   {   'code': '>>> def pub_test_compute_cer():\n'
                                               '...     test_cer = character_error_rate(\n'
                                               '...         ["this is the prediction", "this", ""],\n'
                                               '...         ["there is an other sample", "hi", ""]\n'
                                               '...     )\n'
                                               "...     assert isinstance(test_cer, torch.Tensor), f'The outputs should be `torch.Tensor` type instead of {type(test_cer)}.'\n"
                                               "...     assert torch.isclose(test_cer, torch.tensor(0.7308), atol=1e-4), f'The results do not match with references - {test_cer.item()} != 0.7308.'\n"
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_compute_cer()\n',
                                       'failure_message': 'Failed to test the `compute_cer()`.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 3}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
