OK_FORMAT = True

test = {   'name': 'metric-torchmetric-impl',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_cer_metric():\n'
                                               '...     test_metric = CharErrorRate()\n'
                                               '...     test_metric.update(\n'
                                               '...         ["this is the prediction", "this", ""],\n'
                                               '...         ["there is an other sample", "hi", ""]\n'
                                               '...     )\n'
                                               "...     assert (test_metric.errors, test_metric.total) == (torch.tensor(19.), torch.tensor(26.)), 'After calling the metric update, the corresponding "
                                               "state does not change.'\n"
                                               '...     test_metric.update("hello world", "hello intro world hlt")\n'
                                               "...     assert (test_metric.errors, test_metric.total) == (torch.tensor(29.), torch.tensor(47.)), 'After calling the metric update, the corresponding "
                                               "state does not change - ' + str(test_metric.errors) + str(test_metric.total)\n"
                                               '...     result = test_metric.compute()\n'
                                               "...     assert isinstance(result, torch.Tensor), f'The metric result should be `torch.Tensor` but got {type(result)}.'\n"
                                               "...     assert torch.isclose(result, torch.tensor(0.6170), atol=1e-4), f'CER does not match - {result.item()} != 0.6170.'\n"
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_cer_metric()\n',
                                       'failure_message': 'Failed to test the CER metric.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
