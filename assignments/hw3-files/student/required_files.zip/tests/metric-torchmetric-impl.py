OK_FORMAT = True

test = {   'name': 'metric-torchmetric-impl',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> def pub_test_cer_metric():\n...     assert False, 'This is currently a placeholder.'\n>>> \n>>> \n>>> pub_test_cer_metric()\n",
                                       'failure_message': 'Failed to test the CER metric.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
