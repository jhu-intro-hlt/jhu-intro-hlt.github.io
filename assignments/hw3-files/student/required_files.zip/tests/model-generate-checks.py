OK_FORMAT = True

test = {   'name': 'model-generate-checks',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': '>>> def pub_test_generate_interface():\n'
                                               '...     # This test tries to invoke generation API as what we are doing at the validation step\n'
                                               '...     decode_as_str(\n'
                                               '...         cmudict_corpus.tgt_vocab,\n'
                                               '...         test_model.generate(\n'
                                               '...             input_ids=torch.tensor([[6, 13, 12, 10], [6, 2, 10, 13]], dtype=torch.long),\n'
                                               '...             attention_mask=torch.tensor([[True, True, True, True], [True, True, True, False]], dtype=torch.bool)\n'
                                               '...         )\n'
                                               '...     )\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> pub_test_generate_interface()\n',
                                       'failure_message': 'Failed to test `generate()` method.',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 5}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
